package roles

import (
	//"fmt"
	"net"
	//"github.com/ellenkhoo/ElevatorProject/elevator"

)



func StartBackup(rank int, conn net.Conn) {
	// IMPLEMENT BACKUP LOGIC
	// fmt.Println("Starting backup")

	// var allElevStates = make(map[string]elevator.ElevStates)
	// var globalHallRequests [][2]bool	

	
}
