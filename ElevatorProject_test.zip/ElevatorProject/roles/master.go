package roles

// import (
// 	"fmt"
// 	"net"
// 	"sync"
// 	"github.com/ellenkhoo/ElevatorProject/elevator"
// )



// func StartMaster(rank int, port string, elevConn net.Conn) {

// 	fmt.Println("Starting master")

// 	var allElevStates = make(map[string]elevator.ElevStates)
// 	var globalHallRequests [][2]bool

// 	select {}
// }
